The paragraph example demonstrates how to create a paragraph
screen for display of various styles of text and graphics.
